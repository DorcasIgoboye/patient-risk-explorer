# patient-risk-explorer
Interactive demo for synthetic patient risk prediction (diabetes and heart) with Streamlit, Rich CLI, and SHAP
