import os, json
import pandas as pd
import matplotlib.pyplot as plt
import shap
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, roc_auc_score, confusion_matrix, classification_report
from joblib import dump

# Paths
DATA = os.path.join("data", "synthetic_patients.csv")
MODELS = "models"
REPORTS = "reports"
os.makedirs(MODELS, exist_ok=True)
os.makedirs(REPORTS, exist_ok=True)

# Load dataset
df = pd.read_csv(DATA)

# Diabetes task
X_d = df[["age","bmi","glucose","family_history","activity_hours"]]
y_d = df["diabetes"]

# Heart task
X_h = df[["age","bmi","systolic","smoking","ldl"]]
y_h = df["heart"]

def train_task(X, y, name):
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)
    clf = LogisticRegression(max_iter=1000).fit(X_train, y_train)
    dump(clf, os.path.join(MODELS, f"{name}.joblib"))

    # Metrics
    y_pred = clf.predict(X_test)
    y_prob = clf.predict_proba(X_test)[:,1]
    metrics = {
        "accuracy": accuracy_score(y_test, y_pred),
        "roc_auc": roc_auc_score(y_test, y_prob),
        "report": classification_report(y_test, y_pred, output_dict=True)
    }
    with open(os.path.join(REPORTS, f"{name}_metrics.json"), "w") as f:
        json.dump(metrics, f, indent=2)

    # Confusion matrix plot
    cm = confusion_matrix(y_test, y_pred)
    plt.imshow(cm, cmap="Blues")
    plt.title(f"{name} confusion matrix")
    plt.savefig(os.path.join(REPORTS, f"{name}_confusion.png"))
    plt.close()

    # SHAP explainability
    explainer = shap.LinearExplainer(clf, X_train)
    shap_values = explainer.shap_values(X_test)
    shap.summary_plot(shap_values, X_test, show=False)
    plt.savefig(os.path.join(REPORTS, f"{name}_shap.png"))
    plt.close()

    print(f"{name} model trained. Accuracy={metrics['accuracy']:.3f}, ROC_AUC={metrics['roc_auc']:.3f}")

train_task(X_d, y_d, "diabetes")
train_task(X_h, y_h, "heart")
